/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * Copyright 2011 IBM. All rights reserved.
 * 
 * Use is subject to license terms.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0. You can also
 * obtain a copy of the License at http://odftoolkit.org/docs/license.txt
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ************************************************************************/
package org.odftoolkit.simple.sample.demo7;

import org.odftoolkit.simple.SpreadsheetDocument;
import org.odftoolkit.simple.TextDocument;
import org.odftoolkit.simple.common.field.Field;
import org.odftoolkit.simple.common.field.Fields;
import org.odftoolkit.simple.common.field.VariableField;
import org.odftoolkit.simple.common.navigation.FieldSelection;
import org.odftoolkit.simple.common.navigation.TextNavigation;
import org.odftoolkit.simple.common.navigation.TextSelection;
import org.odftoolkit.simple.table.Row;
import org.odftoolkit.simple.table.Table;

public class FieldsDemo {
	
	public static void main(String[] args) {
		try {
			// create offer letter template with sample offer letter.
			createFieldTemplate();
			// generate offer letters for the candidates from spreadsheet document.
			generateOfferLetterDocument();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void createFieldTemplate() throws Exception {
		TextDocument sampleDocument = TextDocument.loadDocument("Tom's Offer.odt");
		// replace offer date with FixedDateField
		TextNavigation search = new TextNavigation("2011-01-20", sampleDocument);
		while (search.hasNext()) {
			TextSelection item = (TextSelection) search.nextSelection();
			FieldSelection fieldSelection = new FieldSelection(item);
			fieldSelection.replaceWithSimpleField(Field.FieldType.FIXED_DATE_FIELD);
		}
		// replace candidate name with UserVariableField
		VariableField candidateVar = Fields.createUserVariableField(sampleDocument, "candidateVar", "Tom King");
		search = new TextNavigation("Tom King", sampleDocument);
		while (search.hasNext()) {
			TextSelection item = (TextSelection) search.nextSelection();
			FieldSelection fieldSelection = new FieldSelection(item);
			fieldSelection.replaceWithVariableField(candidateVar);
		}
		// replace job title with UserVariableField
		VariableField jobTitleVar = Fields.createUserVariableField(sampleDocument, "jobTitleVar", "software engineer");
		search = new TextNavigation("software engineer", sampleDocument);
		while (search.hasNext()) {
			TextSelection item = (TextSelection) search.nextSelection();
			FieldSelection fieldSelection = new FieldSelection(item);
			fieldSelection.replaceWithVariableField(jobTitleVar);
		}
		// replace branch with UserVariableField
		VariableField branchVar = Fields.createUserVariableField(sampleDocument, "branchVar", "R&D");
		search = new TextNavigation("R&D", sampleDocument);
		while (search.hasNext()) {
			TextSelection item = (TextSelection) search.nextSelection();
			FieldSelection fieldSelection = new FieldSelection(item);
			fieldSelection.replaceWithVariableField(branchVar);
		}
		// replace onboard date with UserVariableField
		VariableField onBoardDateVar = Fields.createUserVariableField(sampleDocument, "onBoardDateVar", "2011-03-12");
		search = new TextNavigation("2011-03-12", sampleDocument);
		while (search.hasNext()) {
			TextSelection item = (TextSelection) search.nextSelection();
			FieldSelection fieldSelection = new FieldSelection(item);
			fieldSelection.replaceWithVariableField(onBoardDateVar);
		}
		// replace salary with ConditionField
		search = new TextNavigation("6,000.00", sampleDocument);
		while (search.hasNext()) {
			TextSelection item = (TextSelection) search.nextSelection();
			FieldSelection fieldSelection = new FieldSelection(item);
			fieldSelection.replaceWithConditionField("jobTitleVar != \"Secretary\"", "6,000.00", "5,500.00");
		}
		// replace consolidated allowance with HiddenTextField
		search = new TextNavigation(" and a Consolidated Allowance of 400\\$ per month", sampleDocument);
		while (search.hasNext()) {
			TextSelection item = (TextSelection) search.nextSelection();
			FieldSelection fieldSelection = new FieldSelection(item);
			fieldSelection.replaceWithHiddenTextField("branchVar == \"Sales\"", " and a Consolidated Allowance of 400$ per month");
		}
		// replace certificates/testimonials with ConditionField
		Fields.createUserVariableField(sampleDocument, "campusHireVar", "N");
		search = new TextNavigation("\\* Educational certificates", sampleDocument);
		while (search.hasNext()) {
			TextSelection item = (TextSelection) search.nextSelection();
			FieldSelection fieldSelection = new FieldSelection(item);
			fieldSelection.replaceWithConditionField("campusHireVar == \"Y\"", "* Educational certificates", "* Experience certificates from previous employers\n* Copy of resignation/acceptation letter and relieving letter");
		}
		sampleDocument.save("OfferTemplate.odt");
	}

	public static void generateOfferLetterDocument() throws Exception {
		TextDocument templateDocument = TextDocument.loadDocument("OfferTemplate.odt");
		SpreadsheetDocument dataDocument = SpreadsheetDocument.loadDocument("Candidates.ods");
		Table table = dataDocument.getTableByName("Sheet1");
		int rowCount = table.getRowCount();
		for(int i = 1; i<rowCount; i++){
			Row row = table.getRowByIndex(i);
			String name = row.getCellByIndex(0).getDisplayText();
			VariableField candidateVar = templateDocument.getVariableFieldByName("candidateVar");
			candidateVar.updateField(name, null);
			String jobTitle = row.getCellByIndex(1).getDisplayText();
			VariableField jobTitleVar = templateDocument.getVariableFieldByName("jobTitleVar");
			jobTitleVar.updateField(jobTitle, null);
			String branch = row.getCellByIndex(2).getDisplayText();
			VariableField branchVar = templateDocument.getVariableFieldByName("branchVar");
			branchVar.updateField(branch, null);
			String isCampusHire = row.getCellByIndex(3).getDisplayText();
			VariableField campusHireVar = templateDocument.getVariableFieldByName("campusHireVar");
			campusHireVar.updateField(isCampusHire, null);
			String onBoradDate = row.getCellByIndex(4).getDisplayText();
			VariableField onBoardDateVar = templateDocument.getVariableFieldByName("onBoardDateVar");
			onBoardDateVar.updateField(onBoradDate, null);
			templateDocument.save(name+"'s offer letter.odt");
		}
	}
}
