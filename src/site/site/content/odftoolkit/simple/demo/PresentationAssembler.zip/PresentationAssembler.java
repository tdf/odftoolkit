/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 *
 * Copyright 2011 IBM. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0. You can also
 * obtain a copy of the License at http://odftoolkit.org/docs/license.txt
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ************************************************************************/

import java.io.File;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.odftoolkit.simple.PresentationDocument;

/**
 * This class is a demo to show the presentation API of Simple Java API for ODF.
 * 
 *
 */
public class PresentationAssembler {

	ArrayList<String> sourceNames = new ArrayList<String>();
	ArrayList<String> pageDesc = new ArrayList<String>();
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		if (args.length<1)
		{
			System.out.println("PresentationAssembler -in one.odp(1-8) -in two.odp -in three.odp(1,3,5) -out out.odp");
		}
		
		PresentationAssembler assembler = new PresentationAssembler();
		assembler.assemble(args);
	}
	
	/**
	 * This method can accept the parameter of command line, analysis the command line parameters,
	 * and assemble presentations with Simple API.
	 * @param args - the command line parameters
	 * @throws Exception
	 */
	public void assemble(String[] args) throws Exception
	{
		String outputFileName="default.odp";
		int pageIndex = 1;
		PresentationDocument doc = PresentationDocument.newPresentationDocument();
		int i=0;
		while (i<args.length)
		{
			String param = args[i];
			if (param.equals("-out")) //get the output file name
				outputFileName = args[++i];
			else if (param.equals("-in")) //get the input file name 
			{
				String pageDesc = args[++i];
				String filename = pageDesc, pagelist;
				int indexStart = pageDesc.indexOf('('); //get the page numbers
				int[] srcPages = null;
				if (indexStart>-1)
				{
					filename = pageDesc.substring(0, indexStart);
					pagelist = pageDesc.substring(indexStart+1, pageDesc.length()-1);
					srcPages = getPageNumbers(pagelist); //analysis the page number description 
													     //and return all page numbers that need to be copied
				}
				PresentationDocument sourceDoc = PresentationDocument.loadDocument(new File(filename));
				if (srcPages==null)
				{
					doc.appendPresentation(sourceDoc);
					pageIndex += sourceDoc.getSlideCount();
				} else for(int j=0;j<srcPages.length;j++)
				{
					doc.copyForeignSlide(pageIndex, sourceDoc, srcPages[j]);
					pageIndex++;
				}
			}
			i++;
		}
		doc.deleteSlideByIndex(0);
		doc.save(outputFileName);
		doc.close();
	}

	/**
	 * 
	 * @param pageDesc
	 * @return
	 */
	int[] getPageNumbers(String pageDesc)
	{
		ArrayList<Integer> al = new ArrayList<Integer>();
		if (pageDesc==null)
			return null;
		
		StringTokenizer token = new StringTokenizer(pageDesc, ",");
		while (token.hasMoreTokens())
		{
			String s = token.nextToken();
			int index = s.indexOf('-');
			if (index==-1)
			{
				al.add(Integer.parseInt(s));
			}
			else
			{
				String startI = s.substring(0, index).trim();
				String endI = s.substring(index+1).trim();
				int start = Integer.parseInt(startI);
				int end = Integer.parseInt(endI);
				for(int i=start;i<=end;i++)
					al.add(i);
			}
		}
		
		int[] returnList = new int[al.size()];
		for(int i=0;i<returnList.length;i++)
		{
			returnList[i] = al.get(i).intValue()-1;
		}
		return returnList;
	}
	
}
