/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * Copyright 2011 IBM. All rights reserved.
 * 
 * Use is subject to license terms.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0. You can also
 * obtain a copy of the License at http://odftoolkit.org/docs/license.txt
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ************************************************************************/


import java.util.Iterator;

import org.odftoolkit.simple.SpreadsheetDocument;
import org.odftoolkit.simple.TextDocument;
import org.odftoolkit.simple.style.StyleTypeDefinitions.VerticalAlignmentType;
import org.odftoolkit.simple.table.Cell;
import org.odftoolkit.simple.table.CellRange;
import org.odftoolkit.simple.table.Table;
import org.odftoolkit.simple.text.list.List;
import org.odftoolkit.simple.text.list.ListItem;

/**
 * This is a demo to show how to convert between List and Table. The first level
 * list item will map to the first row (or column). The second level list item
 * will map to the second row (or column). The first level list item with
 * several sub list items will be mapped to a merged cell.
 * 
 * @since 0.4
 */
public class ListTableConvertor {

	public static void main(String[] args) {
		try {
			TextDocument textDoc = TextDocument.loadDocument("ListTable.odt");
			SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.loadDocument("TableList.ods");
			// covert list in text document to spreadsheet table
			Iterator<List> listIterator = textDoc.getListIterator();
			int i = 1;
			String[] tableLabel = { "DEPARTMENT", "MANAGER", "EMPLOYEE" };
			while (listIterator.hasNext()) {
				List list = listIterator.next();
				Table newTable = Table.newTable(spreadsheetDoc);
				for (int columnIndex = 0; columnIndex < tableLabel.length; columnIndex++) {
					newTable.getCellByPosition(columnIndex, 0).setStringValue(tableLabel[columnIndex]);
				}
				newTable.setTableName("ListTable" + (i++));
				convertFromListToTable(list, newTable, 0, 1);
			}
			spreadsheetDoc.save("TableListUpdate.ods");
			// covert table in spreadsheet to list in text document
			Table sheet1 = spreadsheetDoc.getTableByName("Sheet1");
			textDoc.newParagraph("");
			textDoc.newParagraph("ListConvertedFromTable");
			List newList = textDoc.addList();
			convertFromTableToList(sheet1, newList, 0, 0, sheet1.getColumnCount() - 1, sheet1.getRowCount() - 1);
			textDoc.save("ListTableUpdate.odt");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static int convertFromListToTable(List list, Table table, int startColumn, int startRow) {
		java.util.List<ListItem> items = list.getItems();
		int newItemCount = startRow;
		for (ListItem item : items) {
			Cell cell = table.getCellByPosition(startColumn, newItemCount);
			cell.setStringValue(item.getTextContent());
			cell.setVerticalAlignment(VerticalAlignmentType.MIDDLE);
			Iterator<List> listIterator = item.getListIterator();
			startRow = newItemCount;
			while (listIterator.hasNext()) {
				List subList = listIterator.next();
				newItemCount = convertFromListToTable(subList, table, startColumn + 1, newItemCount);
			}
			// merge
			CellRange cellRange = table.getCellRangeByPosition(startColumn, startRow, startColumn, newItemCount);
			cellRange.merge();
			newItemCount++;
		}
		if (list.size() > 0) {
			return newItemCount - 1;
		} else {
			return startRow;
		}
	}

	private static void convertFromTableToList(Table table, List list, int startColumn, int startRow, int endColumn,
			int endRow) {
		while (startRow <= endRow) {
			Cell cell = table.getCellByPosition(startColumn, startRow);
			int rowSpannedNumber = cell.getRowSpannedNumber();
			String cellText = cell.getDisplayText();
			if (!"".equals(cellText)) {
				ListItem item = list.addItem(cellText);
				int columnSpannedNumber = cell.getColumnSpannedNumber();
				int newStartColumn = startColumn + columnSpannedNumber;
				if (newStartColumn <= endColumn) {
					if (rowSpannedNumber > 1) {
						List subList = item.addList();
						convertFromTableToList(table, subList, newStartColumn, startRow, endColumn, startRow
								+ rowSpannedNumber - 1);
					} else {
						int tmpStartColumn = newStartColumn;
						while (tmpStartColumn <= endColumn) {
							cell = table.getCellByPosition(tmpStartColumn, startRow);
							cellText = cell.getDisplayText();
							if (!"".equals(cellText)) {
								item.setTextContent(item.getTextContent() + "|" + cellText);
							}
							tmpStartColumn += cell.getColumnSpannedNumber();
						}
					}
				}
			}
			startRow += rowSpannedNumber;
		}
	}
}
