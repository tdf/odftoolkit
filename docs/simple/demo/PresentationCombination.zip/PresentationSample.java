package org.odftoolkit.simple.sample;

import org.odftoolkit.simple.presentation.*;
import org.odftoolkit.simple.presentation.Slide.SlideLayout;
import org.odftoolkit.simple.PresentationDocument;
import org.odftoolkit.simple.TextDocument;
import org.odftoolkit.odfdom.dom.element.draw.DrawTextBoxElement;
import org.odftoolkit.odfdom.incubator.doc.text.OdfTextParagraph;
import org.odftoolkit.odfdom.dom.style.props.OdfParagraphProperties;

/**
 * To show the operation of Presentation in Simple API, the Presentation
 * Combination demo is used which combine two independent presentation documents
 * together and extract the notes of each slide out to a Text document.
 */
public class PresentationSample {

	PresentationDocument presentationDoc1;
	PresentationDocument presentationDoc2;
	TextDocument extractedNotes;

	public void getPresentation() {
		try {
			presentationDoc1 = PresentationDocument.loadDocument("Pres1.odp");
			presentationDoc2 = PresentationDocument.loadDocument("Pres2.odp");
		} catch (Exception e) {
			System.err.println("Unable to load document.");
			System.err.println(e.getMessage());
		}
		try {
			extractedNotes = TextDocument.newTextDocument();
		} catch (Exception e) {
			System.err.println("Unable to create text document.");
			System.err.println(e.getMessage());
		}
	}

	public void procSlide() {
		Slide slide;
		Notes notes;
		int count = presentationDoc1.getSlideCount();
		presentationDoc1.deleteSlideByIndex(count - 1);
		slide = presentationDoc1.getSlideByIndex(0);
		slide.setSlideName("XML Cover");
		slide = presentationDoc2.getSlideByName("Cover");
		slide.setSlideName("HTML Cover");
		presentationDoc1.appendPresentation(presentationDoc2);
		slide = presentationDoc1.newSlide(0, "New Cover", SlideLayout.TITLE_ONLY);
		notes = slide.getNotesPage();
		notes.addText("This is the cover of the new presentation document");
		DrawTextBoxElement textbox = (DrawTextBoxElement) slide.getOdfElement().getFirstChild().getFirstChild();
		textbox.newTextPElement().setTextContent("Combined Presentation");
	}

	public void extractNotes() {
		Slide slide;
		Notes notes;
		titleofExtractnotes();
		int count = presentationDoc1.getSlideCount();
		for (int i = 0; i < count; i++) {
			slide = presentationDoc1.getSlideByIndex(i);
			String slidename = slide.getSlideName();
			notes = slide.getNotesPage();
			if (!notes.getOdfElement().getTextContent().isEmpty()) {
				String notestring = notes.getOdfElement().getTextContent().toString().trim();
				fillExtractNotes(notestring, slidename);
			}
		}

	}

	public void fillExtractNotes(String notestext, String slidename) {
		try {
			OdfTextParagraph para = extractedNotes.newParagraph();
			para.setProperty(OdfParagraphProperties.MarginTop, "0.25cm");
			para.setTextContent("Notes of " + slidename + ":");
			para = extractedNotes.newParagraph();
			para.setProperty(OdfParagraphProperties.TextAlign, "justify");
			para.setTextContent("  " + notestext);
		} catch (Exception e) {
			System.err.println("Unable to add paragraph to text document.");
			System.err.println(e.getMessage());
		}
	}

	public void titleofExtractnotes() {
		try {
			OdfTextParagraph para = (OdfTextParagraph) extractedNotes.getContentRoot().getLastChild();
			para.setProperty(OdfParagraphProperties.TextAlign, "center");
			para.setTextContent("Notes of the presentation document");
		} catch (Exception e) {
			System.err.println("Unable to add text to text document.");
			System.err.println(e.getMessage());
		}
	}

	public void saveDocument() {
		try {
			presentationDoc1.save("Presentationsample.odp");
			presentationDoc1.close();
			extractedNotes.save("extractedNotes.odt");
			extractedNotes.close();
		} catch (Exception e) {
			System.err.println("Unable to save document.");
			System.err.println(e.getMessage());
		}
	}

	public static void main(String[] args) {
		PresentationSample app = new PresentationSample();
		app.getPresentation();
		app.procSlide();
		app.extractNotes();
		app.saveDocument();
	}

}
