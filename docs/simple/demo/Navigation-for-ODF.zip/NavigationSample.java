package org.odftoolkit.simple.sample;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.odftoolkit.simple.Document;
import org.odftoolkit.simple.PresentationDocument;
import org.odftoolkit.simple.SpreadsheetDocument;
import org.odftoolkit.simple.TextDocument;
import org.odftoolkit.simple.common.navigation.CellSelection;
import org.odftoolkit.simple.common.navigation.TextNavigation;
import org.odftoolkit.simple.common.navigation.TextSelection;
import org.odftoolkit.simple.table.DefaultCellValueAdapter;
import org.odftoolkit.simple.table.Table;

/**
 * This demo is a simple template application about hotel receipt. By loading
 * the configuration file "consume-data.properties" and navigating the hotel
 * receipt template, this demo could generate the ODF documents (ODT, ODP, and
 * ODS format). In the generated ODF documents, you can see the concrete
 * information about hotel receipt, such as hotel name, customer name, consume
 * time, consume data, total expense, head count, and consume item details
 * including the price, quantity, total expense of each item.
 * 
 */
public class NavigationSample {

	public static void main(String[] args) throws Exception {
		NavigationSample navigationSample = new NavigationSample("consume-data.properties");
		navigationSample.navigateODT();
		navigationSample.navigateODP();
		navigationSample.navigateODS();
	}

	private Properties properties = new Properties();
	private Map<String, String> map = new HashMap<String, String>();

	public void loadConsumeData(String filepath) throws Exception {
		InputStream is = new FileInputStream(filepath);
		properties.load(is);
		is.close();
		// put ConsumeItem as key and TotalExpenseOfItem as value to map
		Enumeration<String> enu = (Enumeration<String>) properties.propertyNames();
		while (enu.hasMoreElements()) {
			String key = (String) enu.nextElement();
			if (key.contains("ConsumeItem")) {
				String consumeItem = properties.getProperty(key);
				String totalExpenseOfItem = properties.getProperty("TotalExpenseOfItem" + key.charAt(key.length() - 1));
				map.put(consumeItem, totalExpenseOfItem);
			}
		}
	}

	NavigationSample(String filepath) throws Exception {
		loadConsumeData(filepath);
	}

	public void navigateODT() throws Exception {

		Iterator it = properties.entrySet().iterator();
		System.out.println("Navigate ODT document: Navigation-ODT-Templating.odt");
		TextDocument textdoc = (TextDocument) Document.loadDocument("Navigation-ODT-Templating.odt");
		TextNavigation search;
		while (it.hasNext()) {
			Map.Entry entry = (Map.Entry) it.next();
			String key = (String) entry.getKey();
			String value = (String) entry.getValue();
			search = new TextNavigation(key, textdoc);
			while (search.hasNext()) {
				TextSelection item = (TextSelection) search.nextSelection();
				item.replaceWith(value);
			}
		}
		// remove ObjectReplacements/ and Thumbnails/
		textdoc.getPackage().removePackageDocument("ObjectReplacements/");
		textdoc.getPackage().removePackageDocument("Thumbnails/");
		textdoc.save("Navigation-ODT-Generated.odt");
		System.out.println("...\nNavigation is over, and Navigation-ODT-Generated.odt is generated");
	}

	public void navigateODP() throws Exception {
		Enumeration<String> enu = (Enumeration<String>) properties.propertyNames();
		System.out.println("Navigate ODP document: Navigation-ODP-Templating.odp");
		PresentationDocument pdoc = (PresentationDocument) Document.loadDocument("Navigation-ODP-Templating.odp");
		TextNavigation search;
		while (enu.hasMoreElements()) {
			String key = (String) enu.nextElement();
			String value = (String) properties.getProperty(key);
			search = new TextNavigation(key, pdoc);
			while (search.hasNext()) {
				TextSelection item;
				item = (TextSelection) search.nextSelection();
				item.replaceWith(value);
			}
		}
		// set the cell value in the table of embedderdocument
		List<Document> embeddedDocuments = pdoc.getEmbeddedDocuments();
		Document embeddedDocument = embeddedDocuments.get(0);
		Table table = embeddedDocument.getTableList().get(0);
		String consumeItem;
		String totalExpenseOfItem;
		int index = 0;
		Iterator<String> it = map.keySet().iterator();
		while (it.hasNext()) {
			index++;
			consumeItem = (String) it.next();
			totalExpenseOfItem = (String) map.get(consumeItem);
			table.getColumnByIndex(0).getCellByIndex(index).setDisplayText(consumeItem);
			table.getColumnByIndex(1).getCellByIndex(index).setDisplayText(totalExpenseOfItem,
					new DefaultCellValueAdapter());
		}
		// remove ObjectReplacements/ and Thumbnails/
		pdoc.getPackage().removePackageDocument("ObjectReplacements/");
		pdoc.getPackage().removePackageDocument("Thumbnails/");
		pdoc.save("Navigation-ODP-Generated.odp");
		System.out.println("...\nNavigation is over, and Navigation-ODP-Generated.odp is generated");

	}

	public void navigateODS() throws Exception {
		Enumeration<String> enu = (Enumeration<String>) properties.propertyNames();
		System.out.println("Navigate ODS document: Navigation-ODS-Templating.ods");
		SpreadsheetDocument ssdoc = (SpreadsheetDocument) Document.loadDocument("Navigation-ODS-Templating.ods");
		TextNavigation search;
		while (enu.hasMoreElements()) {
			String key = (String) enu.nextElement();
			String value = properties.getProperty(key);
			search = new TextNavigation(key, ssdoc);
			while (search.hasNext()) {
				CellSelection item = (CellSelection) search.nextSelection();
				item.advancedReplaceWith(value, new DefaultCellValueAdapter());
			}
		}
		// remove ObjectReplacements/ and Thumbnails/
		ssdoc.getPackage().removePackageDocument("ObjectReplacements/");
		ssdoc.getPackage().removePackageDocument("Thumbnails/");
		ssdoc.save("Navigation-ODS-Generated.ods");
		System.out.println("...\nNavigation is over, and Navigation-ODS-Generated.ods is generated");
	}
}
