If you want to run this demo, you should download the related JAR file.

1. Download the ODFDOM 0.9 or higher version from http://odftoolkit.org/projects/odfdom/downloads

2. Download the Apaches Xerces 2.9.1 or higher version from http://xerces.apache.org/mirrors.cgi

3. Download the Simple Java API 0.3 or higher version from http://odftoolkit.org/projects/simple/downloads

If you want to get more help, please access http://odftoolkit.org/projects/simple/pages/Home.

