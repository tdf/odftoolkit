/************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * Copyright 2011 IBM. All rights reserved.
 * 
 * Use is subject to license terms.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0. You can also
 * obtain a copy of the License at http://odftoolkit.org/docs/license.txt
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ************************************************************************/
package org.odftoolkit.simple.draw;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

import net.sf.json.JSONObject;

import org.odftoolkit.simple.PresentationDocument;
import org.odftoolkit.simple.PresentationDocument.PresentationClass;
import org.odftoolkit.simple.meta.Meta;
import org.odftoolkit.simple.presentation.Slide;

public class BarcodeImageGeneration {

	public static void main(String[] args) {
		try {
			//load the presentation
			PresentationDocument presentation = PresentationDocument.loadDocument("Demotemplate.odp");
			//get the metadata
			Meta metaData = new Meta(presentation.getMetaDom());
			String creator = metaData.getCreator();
			String mailto = metaData.getUserDefinedDataValue("Email");
			String phoneno = metaData.getUserDefinedDataValue("Phone");

			//invoke the 2D barcode service, and get the url
			BarcodeImageGeneration demo = new BarcodeImageGeneration();
			String url = demo.invokepost(creator,mailto,phoneno);
			
			//Add the image to the first slide
			Slide slide = presentation.getSlideByIndex(0);
			Textbox subtitleBox = slide.getTextboxByUsage(PresentationClass.SUBTITLE).get(0);
			FrameRectangle subtitleRect = subtitleBox.getRectangle();
			Image image = Image.newImage(slide, new URI(url));
			FrameRectangle imageRect = image.getRectangle();
			imageRect.setX(subtitleRect.getX()+(subtitleRect.getWidth()-imageRect.getWidth())/2);
			imageRect.setY(subtitleRect.getY()+subtitleRect.getHeight());
			image.setRectangle(imageRect);
			
			presentation.save("output.odp");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	
	public String  invokepost(String name, String tel, String email) {
		String as_url = "https://www.ibm.com/2dbarcode/generateBarcode.php?..."; //this is a fake url. You can use a real url instead. 
		
		StringBuffer sb1=new StringBuffer();
		sb1.append(as_url);
		sb1.append(getData(name, tel, email));
			
		as_url=sb1.toString();
		
		StringBuffer sb=new StringBuffer();
		try {
			URL postUrl = new URL(as_url);
			HttpURLConnection connection = (HttpURLConnection) postUrl
					.openConnection();
			connection.setRequestMethod("GET");
			connection.connect();
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					connection.getInputStream()));
			String line = "";

			while ((line = reader.readLine()) != null) {

				sb.append(line);
			}
			
			reader.close();
			connection.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		//System.out.println(sb.toString());
		return getURLJson(sb.toString());
	}
	
	
	
	public String getData(String name, String tel, String email){
		String json = "{\"FN\":\""+name+"\",\"TEL\":[{\"NUM\":\""+tel+"\",\"TYPE\":\"WORK\"}],\"EMAIL\":[\""+email+"\"]}";
		return json;
	}
	
	public String getURLJson(String json) {
		String imageUrl =null;
		try {
			JSONObject obj = JSONObject.fromObject(json);
			String imageUrlObj = obj.getString("imageUrl");
			if(imageUrlObj!=null){
				int index=imageUrlObj.indexOf(":");
				if(index!=-1){
					imageUrl=imageUrlObj.substring(index+1);
					imageUrl=imageUrl.trim();
					imageUrl=imageUrl.substring(1,imageUrl.length()-2);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return imageUrl;
	}
	
}
